﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyMessages;
using NServiceBus;
using DataComponents;
using NServiceBus.Saga;
using log4net;

namespace UserService
{
	public class UserCreator : Saga<CreateUserSagaData>,
		IAmStartedByMessages<CreateUserCmd>,
		IHandleMessages<VerifyEmailCmd>
	{
		private static ILog Log = LogManager.GetLogger(typeof(UserCreator));

		public override void ConfigureHowToFindSaga()
		{
			ConfigureMapping<CreateUserCmd>(data => data.Email, msg => msg.Email);
			ConfigureMapping<VerifyEmailCmd>(data => data.VerificationString, msg => msg.VerificationCode);
		}

		public void Handle(CreateUserCmd msg)
		{
			this.Data.UserID = msg.UserID;
			this.Data.UserName = msg.UserName;
			this.Data.Email = msg.Email;
			this.Data.Password = msg.Password;

			this.Data.VerificationString = Guid.NewGuid().ToString("N");

			Bus.Send<SendVerificationEmailCmd>(cmd =>
				{
					cmd.Email = Data.Email;
					cmd.UserName = Data.UserName;
					cmd.VerificationCode = Data.VerificationString;
				});
		}

		public void Handle(VerifyEmailCmd msg)
		{
			EVUser u = new EVUser();
			u.UserID = this.Data.UserID;
			u.UserName = this.Data.UserName;
			u.EmailAddress = this.Data.Email;
			u.SetPassword(this.Data.Password);

			UserSchemaDataContext context = new UserSchemaDataContext();
			context.EVUsers.InsertOnSubmit(u);
			context.SubmitChanges();

			UserCreatedEvent e = new UserCreatedEvent
			{
				UserID = Data.UserID,
				UserName = Data.UserName,
				Email = Data.Email
			};
			Bus.Publish(e);

			MarkAsComplete();

			Log.Info(String.Format("Created user {0} with email address {1}.", Data.UserName, Data.Email));

			Bus.Return(0);
		}

		
	}

}
