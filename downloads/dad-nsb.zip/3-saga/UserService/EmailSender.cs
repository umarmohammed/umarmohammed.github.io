﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NServiceBus;
using MyMessages;
using log4net;

namespace UserService
{
	public class EmailSender : IHandleMessages<SendVerificationEmailCmd>
	{
		private static ILog Log = LogManager.GetLogger(typeof(EmailSender));

		public void Handle(SendVerificationEmailCmd msg)
		{
			string url = String.Format("http://localhost:57317/Website/Verify.aspx?id={0}", msg.VerificationCode);

			Log.Info("Let's pretend we sent an email: " + url);
		}
	}
}
