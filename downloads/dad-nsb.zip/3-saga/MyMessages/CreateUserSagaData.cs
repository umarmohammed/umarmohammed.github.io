﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NServiceBus.Saga;

namespace MyMessages
{
	public class CreateUserSagaData : ISagaEntity
	{
		public Guid UserID { get; set; }
		public string UserName { get; set; }
		public string Email { get; set; }
		public string Password { get; set; }
		public string VerificationString { get; set; }

		// Required by NServiceBus Sagas - leave alone
		public Guid Id { get; set; }
		public string OriginalMessageId { get; set; }
		public string Originator { get; set; }
	}
}
