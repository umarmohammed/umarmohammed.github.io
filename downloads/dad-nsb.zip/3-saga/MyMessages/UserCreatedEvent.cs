﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NServiceBus;

namespace MyMessages
{
	public class UserCreatedEvent : IMessage
	{
		public Guid UserID { get; set; }
		public string UserName { get; set; }
		public string Email { get; set; }
	}
}
