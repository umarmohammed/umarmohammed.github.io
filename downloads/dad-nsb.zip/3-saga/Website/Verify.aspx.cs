﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MyMessages;

public partial class Verify : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		string id = Request.QueryString["id"];
		if (String.IsNullOrEmpty(id))
			Result.Text = "Please wait for the verification email to arrive.";
		else
		{
			Global.Bus.Send<VerifyEmailCmd>(cmd => cmd.VerificationCode = id)
				.RegisterWebCallback(returnCode =>
				{
					if (returnCode != 0)
						Result.Text = "Some sort of error happened.  Sorry.";
					else
						Response.Redirect("Login.aspx");
				}, null);
		}
	}
}