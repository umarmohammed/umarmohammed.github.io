﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace DataComponents
{
	public partial class EVUser
	{
		public void SetPassword(string passwordText)
		{
			this.PasswordSalt = Guid.NewGuid();
			this.PasswordHash = ComputeHash(passwordText);
		}

		public bool VerifyPassword(string passwordText)
		{
			return ComputeHash(passwordText) == this.PasswordHash;
		}

		private string ComputeHash(string passwordText)
		{
			byte[] passwordBytes = Encoding.UTF8.GetBytes(passwordText);
			byte[] saltBytes = PasswordSalt.ToByteArray();
			byte[] clearBytes = new byte[saltBytes.Length + passwordBytes.Length];
			Array.Copy(saltBytes, 0, clearBytes, 0, saltBytes.Length);
			Array.Copy(passwordBytes, 0, clearBytes, saltBytes.Length, passwordBytes.Length);

			SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
			byte[] hashBytes = sha.ComputeHash(clearBytes);
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < hashBytes.Length; i++)
				sb.Append(hashBytes[i].ToString("x2"));
			return sb.ToString();
		}
	}
}
