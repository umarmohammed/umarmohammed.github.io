﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataComponents;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		
    }

	protected void OnCreateUser(object sender, EventArgs e)
	{
		Page.Validate();
		if (!Page.IsValid)
			return;

		EVUser u = new EVUser();
		u.UserID = Guid.NewGuid();
		u.UserName = Username.Text;
		u.EmailAddress = Email1.Text;
		u.SetPassword(Password1.Text);

		UserSchemaDataContext context = new UserSchemaDataContext();
		context.EVUsers.InsertOnSubmit(u);
		context.SubmitChanges();

		Response.Redirect("Login.aspx");
	}
}