﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataComponents;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

	protected void OnLogin(object sender, EventArgs e)
	{
		UserSchemaDataContext context = new UserSchemaDataContext();

		EVUser user = context.EVUsers
			.FirstOrDefault(u => u.EmailAddress == Email.Text);

		if (user != null && user.VerifyPassword(Password.Text))
		{
			FormsAuthentication.RedirectFromLoginPage(user.EmailAddress, false);
		}
	}
}