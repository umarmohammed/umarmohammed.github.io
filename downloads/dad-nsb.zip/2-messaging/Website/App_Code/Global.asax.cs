﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NServiceBus;

/// <summary>
/// Summary description for Global
/// </summary>
public class Global : HttpApplication
{
	public static IBus Bus { get; private set; }

	void Application_Start(object sender, EventArgs e)
	{
		Bus = NServiceBus.Configure.WithWeb()
				.Log4Net()
				.DefaultBuilder()
				.XmlSerializer()
				.MsmqTransport()
					.IsTransactional(false)
					.PurgeOnStartup(false)
				.UnicastBus()
					.ImpersonateSender(false)
				.CreateBus()
				.Start();

	}

	void Application_End(object sender, EventArgs e)
	{
		//  Code that runs on application shutdown

	}
}