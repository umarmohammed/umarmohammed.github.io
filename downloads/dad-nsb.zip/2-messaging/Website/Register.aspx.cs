﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataComponents;
using MyMessages;

public partial class Register : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		
	}

	protected void OnCreateUser(object sender, EventArgs e)
	{
		Page.Validate();
		if (!Page.IsValid)
			return;

		CreateUserCmd cmd = new CreateUserCmd();
		cmd.UserID = Guid.NewGuid();
		cmd.UserName = Username.Text;
		cmd.Email = Email1.Text;
		cmd.Password = Password1.Text;

		Global.Bus.Send(cmd);

		Response.Redirect("Login.aspx");
	}
}