﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyMessages;
using NServiceBus;
using DataComponents;

namespace UserService
{
	public class UserCreator : IHandleMessages<CreateUserCmd>
	{
		public IBus Bus { get; set; }

		public void Handle(CreateUserCmd msg)
		{
			EVUser u = new EVUser();
			u.UserID = msg.UserID;
			u.UserName = msg.UserName;
			u.EmailAddress = msg.Email;
			u.SetPassword(msg.Password);

			UserSchemaDataContext context = new UserSchemaDataContext();
			context.EVUsers.InsertOnSubmit(u);
			context.SubmitChanges();
		}
	}
}
