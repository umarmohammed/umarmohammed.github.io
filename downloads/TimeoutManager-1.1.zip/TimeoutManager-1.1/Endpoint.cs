﻿using System;
using System.Configuration;
using NServiceBus;
using NServiceBus.Sagas.Impl;
using Configure = NServiceBus.Configure;

namespace TimeoutManager
{
	public class Endpoint : IConfigureThisEndpoint, AsA_Server, 
		IWantCustomInitialization, 
		ISpecifyMessageHandlerOrdering
	{
		void IWantCustomInitialization.Init()
		{
			Configure config = Configure.With().DefaultBuilder();

			string nameSpace = ConfigurationManager.AppSettings["NameSpace"];
			switch (ConfigurationManager.AppSettings["Serialization"])
			{
				case "xml":
					config.XmlSerializer(nameSpace);
					return;

				case "binary":
					config.BinarySerializer();
					return;
			}
			throw new ConfigurationErrorsException("Serialization can only be one of 'interfaces', 'xml', or 'binary'.");
		}

		/// <summary>
		/// Specifying this order keeps the Timeout Manager from double-processing a message,
		/// according to Udi in his response to the 
		/// <see href="http://tech.groups.yahoo.com/group/nservicebus/message/7024">bug I found</see>.
		/// </summary>
		void ISpecifyMessageHandlerOrdering.SpecifyOrder(Order order)
		{
			order.Specify(First<TimeoutMessageHandler>.Then<SagaMessageHandler>());
		}
	}


}
