using System;
using System.Linq;
using System.Collections.Generic;
using System.Configuration;
using System.Messaging;
using System.Threading;
using System.Xml.Serialization;
using NServiceBus;
using NServiceBus.Saga;
using NServiceBus.Serialization;
using NServiceBus.Unicast.Transport;
using NServiceBus.Utils;

namespace TimeoutManager
{
	public abstract class TimeoutStorageProvider<T> : ITimeoutStorageProvider
	{
		private object padlock = new object();
		private Timer refreshTimer;
		private Timer instanceTimer;
		private List<TimeoutEntry<T>> entries;
		private DateTime entriesEnd;
		private bool started = false;

		public abstract void Init();
		protected abstract T StoreTimeout(IMessageContext context, TimeoutMessage msg);
		protected abstract void RemoveBySagaId(Guid sagaId);
		protected abstract void RemoveTimeout(T id);
		protected abstract List<TimeoutEntry<T>> GetTimeouts(DateTime cutoff);

		/// <summary>
		/// The message serializer, which is injected into the class by TimeoutConfigurer
		/// </summary>
		public IMessageSerializer Serializer { get; set; }

		/// <summary>
		/// The number of minutes to rebuild the in-memory queue after, which is injected
		/// into the class by TimeoutConfigurer
		/// </summary>
		public int RefreshInterval { get; set; }

		/// <summary>
		/// The factor by which the RefreshInterval is multiplied so that timeouts that
		/// expire just after the refresh interval is ended don't get missed while the
		/// list is being reloaded.  This must be greater than 1.0.
		/// </summary>
		public double RefreshMultiplier { get; set; }

		/// <summary>
		/// The action to perform when a timer comes due.
		/// </summary>
		public event Action<string, TimeoutMessage> TimerDue;

		/// <summary>
		/// Initializes the timers that drive the Timeout mechanism
		/// </summary>
		public void Start()
		{
			// Instance timer is set to fire when the next timer is due to go off
			// and reset after every timeout is triggered, or after a new timeout
			// is added
			instanceTimer = new Timer(new TimerCallback(x => FireEvents()));
			
			// Refresh timer controls how often the entire list of entries
			// is re-read from MessageQueue.  It is set to go off immediately
			// in order to do the initial load of timeouts, and repeat every 
			// RefreshInterval minutes.
			refreshTimer = new Timer(new TimerCallback(x => RefreshEntries()), null, TimeSpan.Zero, TimeSpan.FromMinutes(RefreshInterval));

			this.started = true;
		}

		public void Stop()
		{
			this.started = false;

			refreshTimer.Change(Timeout.Infinite, Timeout.Infinite);
			refreshTimer.Dispose();
			refreshTimer = null;

			instanceTimer.Change(Timeout.Infinite, Timeout.Infinite);
			instanceTimer.Dispose();
			instanceTimer = null;
		}

		/// <summary>
		/// Refreshes the in-memory list of timeouts that are going to occur relatively soon
		/// by re-reading the list out of the message queue.  Timeouts that are a long way
		/// off are not loaded into memory.
		/// </summary>
		private void RefreshEntries()
		{
			// Set the cutoff to 20% past the rebuild interval so we have some breathing room to rebuild
			DateTime cutoff = DateTime.Now.AddSeconds(60 * RefreshInterval * 1.2);

			// Get the entries from before the cutoff from the storage provider
			List<TimeoutEntry<T>> newEntries = GetTimeouts(cutoff);

			// Sort the entries by date so we can find the next one
			newEntries.Sort();

			// Replace the list of entries under thread lock
			lock (padlock)
			{
				entries = newEntries;
				entriesEnd = cutoff;
			}

			// Cycle through events to execute any timeouts that are past expiration
			// and set up the instance timer for the next event.
			FireEvents();
		}

		/// <summary>
		/// Add a timeout to the list.
		/// </summary>
		/// <param name="context">The Bus's message context, used to discover the return address.</param>
		/// <param name="msg">The timeout message.</param>
		public void AddTimeout(IMessageContext context, TimeoutMessage msg)
		{
			if (!started)
				throw new InvalidOperationException("The TimeoutStorageProvider must be started first.");

			T msgId = StoreTimeout(context, msg);

			// If the timeout occurs before the current end of our in-memory entries list,
			// add it to the list and reset the instance timer accordingly
			if (msg.Expires < entriesEnd)
				ResetInstanceTimer(new TimeoutEntry<T>(msgId, context.ReturnAddress, msg));	
		}

		public void ClearSaga(Guid sagaId)
		{
			if (!started)
				throw new InvalidOperationException("The TimeoutStorageProvider must be started first.");

			lock (padlock)
			{
				RemoveBySagaId(sagaId);

				// Entries will exist only if timeout is "soon" but we must remove
				// from here as well.  Then if the count changed, we must recalculate
				// the next entry
				int entryCount = this.entries.Count;
				this.entries.RemoveAll(te => te.Timeout.SagaId == sagaId);
				if (entryCount != this.entries.Count)
					ResetInstanceTimer(null);
			}
		}

		/// <summary>
		/// Optionally add a new entry to the in-memory timeout list, then reset
		/// the instance timer to go off when the next timer is due.
		/// </summary>
		/// <param name="newEntry">A new TimeoutEntry to add to the entries list.</param>
		private void ResetInstanceTimer(TimeoutEntry<T> newEntry)
		{
			lock (this.padlock)
			{
				// Add the new entry, if given one, and resort the list
				if (newEntry != null)
				{
					entries.Add(newEntry);
					entries.Sort();
				}

				// If there are no entries left, we can just 
				if (entries.Count > 0)
				{
					// Don't want the definition of "now" changing on us because 
					// we may do math on it later
					DateTime now = DateTime.Now;
					DateTime first = entries[0].Expires;
					if (first < now)
					{
						// Make the instance timer do the work in a thread-pool thread.  If we just called
						// the method here, we would still be subject to the same transaction as the
						// TimeoutMessageHandler's Handle method.
						instanceTimer.Change(0, Timeout.Infinite);
					}
					else
					{
						// Calculate the number of milliseconds until the first event
						// and reset the instance timer
						instanceTimer.Change((int)(first - DateTime.Now).TotalMilliseconds, Timeout.Infinite);
					}
				}
			}
		}

		/// <summary>
		/// Cycle through the in-memory entries.  Send the TimeoutMessage back for those that
		/// are past their expiration dates, and remove their entry from the message queue.
		/// Then, reset the instance timer for the next event.
		/// </summary>
		private void FireEvents()
		{
			lock (padlock)
			{
				for (int i = 0; i < entries.Count; i++)
				{
					// We'll have an independent, unchanging "now" for each evaluated entry
					DateTime now = DateTime.Now;
					TimeoutEntry<T> e = entries[i];
					if (e.Expires < now)
					{
						RemoveTimeout(e.MessageID);
						TimerDue(e.ReturnAddress, e.Timeout);
					}
					else
					{
						int ms = (int)(e.Expires - now).TotalMilliseconds;
						if (ms < 0)
							continue;
						instanceTimer.Change(ms, Timeout.Infinite);
						if (i > 0)
							entries.RemoveRange(0, i);
						return;
					}
				}

				// If we got all the way through the list without finding an entry that's in
				// the future, then we need to clear out the list and turn off the timer
				// until something new comes in.
				entries.Clear();
				instanceTimer.Change(Timeout.Infinite, Timeout.Infinite);
			}
		}
	}
}
