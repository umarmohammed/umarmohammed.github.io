﻿using System;
using System.Configuration;
using NServiceBus;
using NServiceBus.ObjectBuilder;
using NServiceBus.Saga;
using NServiceBus.Serialization;

namespace TimeoutManager
{
	/// <summary>
	/// Configures MsmqTimeoutStorage for use.
	/// </summary>
	public class TimeoutConfigurer : IWantCustomInitialization, IWantToRunAtStartup
	{
		public IBus Bus { get; set; }

		private static ITimeoutStorageProvider storage;

		void IWantCustomInitialization.Init()
		{
			string provider = ConfigurationManager.AppSettings["TimeoutStorageProvider"];
			if (String.IsNullOrEmpty(provider))
				throw new ConfigurationErrorsException("App Setting 'TimeoutStorageProvider' must refer to a class that inherits TimeoutManager.TimeoutStorageProvider");

			int refreshInterval;
			if (!int.TryParse(ConfigurationManager.AppSettings["RefreshIntervalMins"], out refreshInterval) || refreshInterval <= 0)
				throw new ConfigurationErrorsException("App Setting 'RefreshIntervalMins' must be an integral number of minutes greater than 0.");

			double refreshMultiplier;
			if (!double.TryParse(ConfigurationManager.AppSettings["RefreshMultiplier"], out refreshMultiplier) || refreshMultiplier < 1)
				throw new ConfigurationErrorsException("App Setting 'RefreshMultiplier' must be a number greater than 1.0.");

			Configure conf = Configure.Instance;
			IMessageSerializer serializer = conf.Builder.Build<IMessageSerializer>();

			Type t = Type.GetType(provider);
			if (t == null)
				throw new ConfigurationErrorsException("Unable to find type '" + provider + "'.");

			storage = Activator.CreateInstance(t) as ITimeoutStorageProvider;
			storage.Serializer = serializer;
			storage.RefreshInterval = refreshInterval;
			storage.RefreshMultiplier = refreshMultiplier;
			storage.Init();
			conf.Configurer.RegisterSingleton<ITimeoutStorageProvider>(storage);

			conf.Configurer.ConfigureProperty<TimeoutMessageHandler>(h => h.TimeoutStorage, storage);
		}

		public void Run()
		{
			storage.TimerDue += OnTimerDue;
			storage.Start();
		}

		private void OnTimerDue(string destination, TimeoutMessage msg)
		{
			Bus.Send(destination, msg);
		}

		public void Stop()
		{
			storage.Stop();
		}
	}


}
