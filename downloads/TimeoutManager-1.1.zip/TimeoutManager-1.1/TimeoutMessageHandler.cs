﻿using System;
using NServiceBus;
using NServiceBus.Saga;

namespace TimeoutManager
{
	/// <summary>
	/// Handles the timeout messages, either clearing saga data, adding the
	/// timeout to storage, or sending it back if it has already expired.
	/// </summary>
	public class TimeoutMessageHandler : IMessageHandler<TimeoutMessage>
	{
		public IBus Bus { get; set; }
		public ITimeoutStorageProvider TimeoutStorage { get; set; }

		public void Handle(TimeoutMessage message)
		{
			if (message.ClearTimeout)
				TimeoutStorage.ClearSaga(message.SagaId);
			else if (message.HasNotExpired())
				TimeoutStorage.AddTimeout(Bus.CurrentMessageContext, message);
			else
				Bus.Send(Bus.CurrentMessageContext.ReturnAddress, message);
			Bus.DoNotContinueDispatchingCurrentMessageToHandlers();
		}

		

	}



}
