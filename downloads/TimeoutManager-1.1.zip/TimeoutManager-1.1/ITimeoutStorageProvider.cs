using System;
using NServiceBus.Serialization;
namespace TimeoutManager
{
	/// <summary>
	/// The interface that a Timeout Storage Provider must implement.
	/// </summary>
	public interface ITimeoutStorageProvider
	{
		void AddTimeout(NServiceBus.IMessageContext context, NServiceBus.Saga.TimeoutMessage msg);
		void ClearSaga(Guid sagaId);
		void Init();
		int RefreshInterval { get; set; }
		double RefreshMultiplier { get; set; }
		IMessageSerializer Serializer { get; set; }
		void Start();
		void Stop();
		event Action<string, NServiceBus.Saga.TimeoutMessage> TimerDue;
	}
}
