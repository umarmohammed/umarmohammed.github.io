﻿using System;
using NServiceBus.Saga;

namespace TimeoutManager
{
	/// <summary>
	/// Represents an in-memory Timeout instance with a MessageID of type T.
	/// </summary>
	/// <typeparam name="T">
	/// The type of the ID used to store the timeout.  In MSMQ this would be a string
	/// to store the message's Id parameter.  For a database storage provider, the
	/// type might be a Guid or an integer corresponding to the database table's
	/// primary key.
	/// </typeparam>
	public class TimeoutEntry<T> : IComparable<TimeoutEntry<T>>
	{
		public T MessageID { get; private set; }
		public TimeoutMessage Timeout { get; private set; }
		public string ReturnAddress { get; private set; }
		public DateTime Expires { get; private set; }

		public TimeoutEntry(T messageID, string returnAddress, TimeoutMessage timeout)
		{
			this.MessageID = messageID;
			this.Timeout = timeout;
			this.Expires = timeout.Expires;
			this.ReturnAddress = returnAddress;
		}

		/// <summary>
		/// Implementation of IComparable&lt;TimeoutEntry&lt;T&gt;&gt; allows
		/// the timeouts to be sorted by expiration date.
		/// </summary>
		public int CompareTo(TimeoutEntry<T> other)
		{
			return Expires.CompareTo(other.Expires);
		}
	}
}
