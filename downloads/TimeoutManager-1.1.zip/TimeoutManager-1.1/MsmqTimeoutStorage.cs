﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NServiceBus;
using NServiceBus.Saga;
using System.Messaging;
using NServiceBus.Utils;
using System.Configuration;

namespace TimeoutManager
{
	/// <summary>
	/// Provides timeout storage using Microsoft Message Queue.  The type parameter
	/// corresponds to the MSMQ message Id.
	/// </summary>
	public class MsmqTimeoutStorage : TimeoutStorageProvider<string>
	{
		private MessageQueue q;
		private string queue;

		public override void Init()
		{
			// Set up the storage queue
			this.queue = ConfigurationManager.AppSettings["TimeoutStorageQueue"];
			if (String.IsNullOrEmpty(this.queue))
				throw new ConfigurationErrorsException("App Setting 'TimeoutStorageQueue' must be specified.");

			MsmqUtilities.CreateQueueIfNecessary(this.queue);
			string path = MsmqUtilities.GetFullPath(this.queue);
			this.q = new MessageQueue(path);

			bool transactional;
			try
			{
				transactional = this.q.Transactional;
			}
			catch (Exception x)
			{
				throw new ArgumentException(String.Format("There is a problem with timeout storage queue {0}. See inner exception for details.", this.queue), x);
			}

			MessagePropertyFilter mpf = new MessagePropertyFilter();
			mpf.SetAll();
			this.q.MessageReadPropertyFilter = mpf;
		}		

		protected override string StoreTimeout(IMessageContext context, TimeoutMessage msg)
		{
			// Create a new MSMQ message to store the timeout
			Message toSend = new Message();
			Serializer.Serialize(new IMessage[] { msg }, toSend.BodyStream);
			toSend.Recoverable = true;
			toSend.ResponseQueue = new MessageQueue(MsmqUtilities.GetFullPath(context.ReturnAddress));
			// Store the SagaId in the label so we can easily clear out the queue by SagaId
			// without having to deserialize the entire message.
			toSend.Label = String.Format("Saga {{{0}}} due {1}", msg.SagaId, msg.Expires);

			// Store the message in the storage queue.
			try
			{
				q.Send(toSend, MessageQueueTransactionType.Automatic);
				return toSend.Id;
			}
			catch (MessageQueueException mqx)
			{
				if (mqx.MessageQueueErrorCode == MessageQueueErrorCode.QueueNotFound)
					throw new ConfigurationErrorsException("The destination queue '" + queue + "' could not be found.");
				throw;
			}
		}

		protected override void RemoveBySagaId(Guid sagaId)
		{
			// Doing a String.StartsWith on the label should be quicker than
			// deserializing each message to look for the SagaId
			string lookFor = String.Format("Saga {{{0}}}", sagaId);

			Message[] allMessages = this.q.GetAllMessages();
			foreach (Message m in allMessages.Where(m => m.Label.StartsWith(lookFor, StringComparison.Ordinal)))
				this.q.ReceiveById(m.Id, MessageQueueTransactionType.Automatic);
		}

		protected override void RemoveTimeout(string id)
		{
			q.ReceiveById(id, MessageQueueTransactionType.Automatic);
		}

		protected override List<TimeoutEntry<string>> GetTimeouts(DateTime cutoff)
		{
			Message[] allMessages = this.q.GetAllMessages();
			List<TimeoutEntry<string>> newEntries = new List<TimeoutEntry<string>>(allMessages.Length);
			foreach (Message m in this.q.GetAllMessages())
			{
				// Reconstitute the TimeoutMessage
				IMessage[] messages = Serializer.Deserialize(m.BodyStream);
				TimeoutMessage timeout = messages[0] as TimeoutMessage;

				// If it is going to happen soon, create a new in-memory entry for it
				if (timeout.Expires < cutoff)
					newEntries.Add(new TimeoutEntry<string>(m.Id, MsmqUtilities.GetIndependentAddressForQueue(m.ResponseQueue), timeout));
			}
			return newEntries;
		}
	}
}
