﻿using System;
using System.Configuration;
using NServiceBus;
using NServiceBus.ObjectBuilder;
using NServiceBus.Saga;
using NServiceBus.Serialization;

namespace TimeoutManager
{
	/// <summary>
	/// Configures MsmqTimeoutStorage for use.
	/// </summary>
	public class TimeoutConfigurer : IWantCustomInitialization, IWantToRunAtStartup
	{
		public IBus Bus { get; set; }

		private static MsmqTimeoutStorage storage;

		void IWantCustomInitialization.Init()
		{
			string queueName = ConfigurationManager.AppSettings["TimeoutStorageQueue"];
			if (String.IsNullOrEmpty(queueName))
				throw new ConfigurationErrorsException("App Setting 'TimeoutStorageQueue' must be specified.");

			int refreshInterval;
			if (!int.TryParse(ConfigurationManager.AppSettings["RefreshIntervalMins"], out refreshInterval) || refreshInterval <= 0)
				throw new ConfigurationErrorsException("App Setting 'RefreshIntervalMins' must be an integral number of minutes greater than 0.");

			Configure conf = Configure.Instance;
			IMessageSerializer serializer = conf.Builder.Build<IMessageSerializer>();

			storage = new MsmqTimeoutStorage();
			storage.Queue = queueName;
			storage.Serializer = serializer;
			storage.RefreshInterval = refreshInterval;
			conf.Configurer.RegisterSingleton<MsmqTimeoutStorage>(storage);

			conf.Configurer.ConfigureProperty<TimeoutMessageHandler>(h => h.TimeoutStorage, storage);
		}

		public void Run()
		{
			storage.TimerDue += OnTimerDue;
			storage.Init();
		}

		private void OnTimerDue(string destination, TimeoutMessage msg)
		{
			Bus.Send(destination, msg);
		}

		public void Stop()
		{
		}
	}


}
