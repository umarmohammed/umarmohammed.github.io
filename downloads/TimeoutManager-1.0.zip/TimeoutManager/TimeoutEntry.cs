﻿using System;
using NServiceBus.Saga;

namespace TimeoutManager
{
	/// <summary>
	/// Represents an in-memory Timeout instance.
	/// </summary>
	public class TimeoutEntry : IComparable<TimeoutEntry>
	{
		public string MessageID { get; private set; }
		public TimeoutMessage Timeout { get; private set; }
		public string ReturnAddress { get; private set; }
		public DateTime Expires { get; private set; }

		public TimeoutEntry(string messageID, string returnAddress, TimeoutMessage timeout)
		{
			this.MessageID = messageID;
			this.Timeout = timeout;
			this.Expires = timeout.Expires;
			this.ReturnAddress = returnAddress;
		}

		public int CompareTo(TimeoutEntry other)
		{
			return Expires.CompareTo(other.Expires);
		}
	}
}
