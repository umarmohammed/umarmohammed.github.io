﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace HgImport
{
	public static class Extensions
	{
		public static string GetNameAtt(this XmlElement xe)
		{
			return xe.Attributes["name"].Value;
		}

		public static XmlElement FindDirNode(this XmlElement xe, string dirName)
		{
			return xe.SelectSingleNode("dir[@name='" + dirName + "']") as XmlElement;
		}

		public static XmlElement FindFileNode(this XmlElement xe, string fileName)
		{
			return xe.SelectSingleNode("file[@name='" + fileName + "']") as XmlElement;
		}

		public static void CreateChildDir(this XmlElement parent, string dirName)
		{
			XmlElement child = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "dir", null) as XmlElement;
			XmlAttribute att = parent.OwnerDocument.CreateAttribute("name");
			att.Value = dirName;
			child.Attributes.Append(att);
			parent.AppendChild(child);
		}

		public static void CreateChildFile(this XmlElement parent, string fileName)
		{
			XmlElement child = parent.OwnerDocument.CreateNode(XmlNodeType.Element, "file", null) as XmlElement;
			XmlAttribute att = parent.OwnerDocument.CreateAttribute("name");
			att.Value = fileName;
			child.Attributes.Append(att);
			parent.AppendChild(child);
		}
	}
}
