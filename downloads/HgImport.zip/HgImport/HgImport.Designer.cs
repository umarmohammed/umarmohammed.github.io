﻿namespace HgImport
{
	partial class HgImport
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.SVNUrl = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.BtnConvert = new System.Windows.Forms.Button();
			this.AuthorMap = new System.Windows.Forms.TextBox();
			this.LblCmdOutput = new System.Windows.Forms.Label();
			this.BtnAbort = new System.Windows.Forms.Button();
			this.tabs = new System.Windows.Forms.TabControl();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.SubrepoTree = new System.Windows.Forms.TreeView();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.LblSubOutput = new System.Windows.Forms.Label();
			this.tabs.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.SuspendLayout();
			// 
			// SVNUrl
			// 
			this.SVNUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.SVNUrl.Location = new System.Drawing.Point(103, 12);
			this.SVNUrl.Name = "SVNUrl";
			this.SVNUrl.Size = new System.Drawing.Size(539, 20);
			this.SVNUrl.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(85, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "SVN Trunk URL";
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.button1.Location = new System.Drawing.Point(648, 10);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(68, 23);
			this.button1.TabIndex = 2;
			this.button1.Text = "Load SVN";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.LoadSvnIntoXml);
			// 
			// BtnConvert
			// 
			this.BtnConvert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.BtnConvert.Location = new System.Drawing.Point(22, 339);
			this.BtnConvert.Name = "BtnConvert";
			this.BtnConvert.Size = new System.Drawing.Size(75, 23);
			this.BtnConvert.TabIndex = 3;
			this.BtnConvert.Text = "Convert";
			this.BtnConvert.UseVisualStyleBackColor = true;
			this.BtnConvert.Click += new System.EventHandler(this.BtnConvert_Click);
			// 
			// AuthorMap
			// 
			this.AuthorMap.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AuthorMap.Location = new System.Drawing.Point(3, 3);
			this.AuthorMap.Multiline = true;
			this.AuthorMap.Name = "AuthorMap";
			this.AuthorMap.Size = new System.Drawing.Size(690, 263);
			this.AuthorMap.TabIndex = 5;
			// 
			// LblCmdOutput
			// 
			this.LblCmdOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.LblCmdOutput.AutoSize = true;
			this.LblCmdOutput.Location = new System.Drawing.Point(16, 380);
			this.LblCmdOutput.Name = "LblCmdOutput";
			this.LblCmdOutput.Size = new System.Drawing.Size(89, 13);
			this.LblCmdOutput.TabIndex = 6;
			this.LblCmdOutput.Text = "Command Output";
			// 
			// BtnAbort
			// 
			this.BtnAbort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.BtnAbort.Location = new System.Drawing.Point(103, 339);
			this.BtnAbort.Name = "BtnAbort";
			this.BtnAbort.Size = new System.Drawing.Size(75, 23);
			this.BtnAbort.TabIndex = 7;
			this.BtnAbort.Text = "Abort";
			this.BtnAbort.UseVisualStyleBackColor = true;
			this.BtnAbort.Click += new System.EventHandler(this.OnAbort);
			// 
			// tabs
			// 
			this.tabs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.tabs.Controls.Add(this.tabPage2);
			this.tabs.Controls.Add(this.tabPage1);
			this.tabs.Location = new System.Drawing.Point(12, 38);
			this.tabs.Name = "tabs";
			this.tabs.SelectedIndex = 0;
			this.tabs.Size = new System.Drawing.Size(704, 295);
			this.tabs.TabIndex = 8;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.SubrepoTree);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(696, 269);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Subrepository Conversions";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// SubrepoTree
			// 
			this.SubrepoTree.CheckBoxes = true;
			this.SubrepoTree.Dock = System.Windows.Forms.DockStyle.Fill;
			this.SubrepoTree.Location = new System.Drawing.Point(3, 3);
			this.SubrepoTree.Name = "SubrepoTree";
			this.SubrepoTree.Size = new System.Drawing.Size(690, 263);
			this.SubrepoTree.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.AuthorMap);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(696, 269);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Author Map";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// LblSubOutput
			// 
			this.LblSubOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.LblSubOutput.AutoSize = true;
			this.LblSubOutput.Location = new System.Drawing.Point(16, 404);
			this.LblSubOutput.Name = "LblSubOutput";
			this.LblSubOutput.Size = new System.Drawing.Size(89, 13);
			this.LblSubOutput.TabIndex = 9;
			this.LblSubOutput.Text = "Command Output";
			// 
			// HgImport
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(728, 437);
			this.Controls.Add(this.LblSubOutput);
			this.Controls.Add(this.tabs);
			this.Controls.Add(this.BtnAbort);
			this.Controls.Add(this.LblCmdOutput);
			this.Controls.Add(this.BtnConvert);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.SVNUrl);
			this.Name = "HgImport";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.HgImport_Load);
			this.tabs.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox SVNUrl;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button BtnConvert;
		private System.Windows.Forms.TextBox AuthorMap;
		private System.Windows.Forms.Label LblCmdOutput;
		private System.Windows.Forms.Button BtnAbort;
		private System.Windows.Forms.TabControl tabs;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TreeView SubrepoTree;
		private System.Windows.Forms.Label LblSubOutput;
	}
}

