﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace HgImport
{
	public partial class HgImport : Form
	{
		private string exePath;
		private string runPath;
		private string workingPath;
		internal static StreamWriter Log;
		internal static StreamWriter Verbose;
		Task task;
		XmlDocument svnDoc;
		List<string> filteringLines = new List<string>();
		List<string> subrepoPaths = new List<string>();

		const string FullConvertRepo = "FullConvert";
		const string FilteredRepo = "FilteredRepo";

		public HgImport()
		{
			InitializeComponent();
			Application.ApplicationExit += new EventHandler(OnAbort);

			exePath = Application.ExecutablePath;
			runPath = Path.GetDirectoryName(exePath);
			workingPath = Path.Combine(runPath, "working");
		}

		private void HgImport_Load(object sender, EventArgs e)
		{
			SetOutput(String.Empty, String.Empty);
		}

		private void BtnConvert_Click(object sender, EventArgs e)
		{
			if (svnDoc == null)
			{
				MessageBox.Show("Must load SVN Details first.");
				return;
			}

			Log = new StreamWriter(Path.Combine(workingPath, "log.txt"), false);
			Verbose = new StreamWriter(Path.Combine(workingPath, "verbose.txt"), false);

			task = Task.Create(o => ClearWorkingDirectory())
			    .ContinueWith(t => FullConvert())
			    .ContinueWith(t => CreateFilter())
			    .ContinueWith(t => MainRepo())
			    .ContinueWith(t => DoSubrepos())
				.ContinueWith(o => AddIgnoreProps())
				.ContinueWith(t => Done());
		}

		private void SetOutput(string msg)
		{
			SetOutput(msg, String.Empty);
		}

		private void SetOutput(string msg, string sub)
		{
			if(msg != null)
				LblCmdOutput.Invoke(new Action(() => LblCmdOutput.Text = msg));
			if (sub != null)
				LblSubOutput.Invoke(new Action(() => LblSubOutput.Text = sub));
		}

		private void ClearWorkingDirectory()
		{
			try
			{
				SetOutput("Clearing working directory...");
				if (Directory.Exists(workingPath))
				{
					foreach (string file in Directory.GetFiles(workingPath))
						File.Delete(file);
					foreach (string dir in Directory.GetDirectories(workingPath))
						Directory.Delete(dir, true);
				}
				Directory.CreateDirectory(workingPath);
			}
			catch (Exception x)
			{
			}
			System.Threading.Thread.Sleep(1000);
		}

		private void FullConvert()
		{
			SetOutput("Beginning initial SVN conversion...");
			string authorPath = Path.Combine(workingPath, "authormap.txt");
			File.WriteAllText(authorPath, AuthorMap.Text);

			string args = String.Format("convert {0} {1} --datesort --authors authormap.txt",
				SVNUrl.Text, FullConvertRepo);
			DoCommand("hg", args, null);

			SetOutput("Updating first-run Hg Repo Working Directory...");
			DoCommand("hg", "up", FullConvertRepo);
		}

		private void CreateFilter()
		{
			
			string hgPath = Path.Combine(workingPath, FullConvertRepo);
			DirectoryInfo hgDir = new DirectoryInfo(hgPath);
			
				CreateFilterRecurse(svnDoc.DocumentElement, hgDir, String.Empty);
				CreateFileMapRecursive(SubrepoTree.Nodes, String.Empty);
		}

		private void CreateFilterRecurse(XmlElement svnNode, DirectoryInfo hgDir, string filterWorkingDir)
		{
			foreach (FileSystemInfo fsi in hgDir.GetFileSystemInfos())
			{
				if (fsi.Name.StartsWith(".hg"))
					continue;

				XmlElement match = (fsi is DirectoryInfo) ? svnNode.FindDirNode(fsi.Name) : svnNode.FindFileNode(fsi.Name);
				if (match == null)
					filteringLines.Add(String.Format("exclude {0}{1}", filterWorkingDir, fsi.Name));
				else if (fsi is DirectoryInfo)
					CreateFilterRecurse(match, fsi as DirectoryInfo, filterWorkingDir + fsi.Name + "/");
			}
		}

		private void CreateFileMapRecursive(TreeNodeCollection nodes, string tnWorkingDir)
		{
			foreach (TreeNode tn in nodes)
			{
				if (tn.Checked)
					subrepoPaths.Add(String.Format("{0}{1}", tnWorkingDir, tn.Name));
				CreateFileMapRecursive(tn.Nodes, tnWorkingDir + tn.Name + "/");
			}
		}

		private void MainRepo()
		{
			string filteringPath = Path.Combine(workingPath, "filtering.txt");
			using (StreamWriter w = new StreamWriter(filteringPath, false))
			{
				filteringLines.ForEach(s => w.WriteLine(s));
				subrepoPaths.ForEach(s => w.WriteLine("exclude {0}", s));
			}

			SetOutput("Beginning filtering conversion of main repo...");
			string filtering = Path.Combine(workingPath, "filtering.txt");

			string args = String.Format("convert {0} {1} --datesort --filemap filtering.txt",
				FullConvertRepo, FilteredRepo);

			DoCommand("hg", args, null);

			SetOutput("Updating filtered repo working directory...");
			DoCommand("hg", "up", FilteredRepo);
		}

		private void DoSubrepos()
		{
			for (int i = 0; i < subrepoPaths.Count; i++ )
			{
				string subrepoPath = subrepoPaths[i];
				string filemapFilename = String.Format("subrep-filemap_{0}.txt", i);
				string filemap = Path.Combine(workingPath, filemapFilename);
				using (StreamWriter w = new StreamWriter(filemap, false))
				{
					filteringLines.ForEach(s => w.WriteLine(s));
					foreach (string excludePath in subrepoPaths)
					{
						if (excludePath == subrepoPath)
						{
							w.WriteLine("include {0}", subrepoPath);
							w.WriteLine("rename {0} .", subrepoPath);
						}
						else if (excludePath.StartsWith(subrepoPath))
							w.WriteLine("exclude {0}", excludePath);
					}

				}

				SetOutput(String.Format("Adding subrepository '{0}'", subrepoPath));
				string args = String.Format("convert {0} {1}/{2} --datesort --filemap {3}",
					FullConvertRepo, FilteredRepo, subrepoPath, filemapFilename);
				DoCommand("hg", args, null);

				SetOutput(String.Format("Updating subrepository '{0}'", subrepoPath));
				DoCommand("hg", "up", String.Format("{0}/{1}", FilteredRepo, subrepoPath));
			}
		}

		private void AddIgnoreProps()
		{
			SetOutput("Querying SVN for svn:ignore properties");
			string args = "propget svn:ignore --recursive --xml " + SVNUrl.Text;
			CmdRunner cmd = new CmdRunner("svn", args, null);
			string xml = String.Join(Environment.NewLine, cmd.GetOutputLines().ToArray());
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(xml);
			XmlNodeList propNodes = doc.SelectNodes("/properties/target");
			char[] splits = new char[] { '\r', '\n' };
			var data = from propNode in propNodes.OfType<XmlNode>()
					   select new
					   {
						   Path = propNode.Attributes["path"].Value,
						   Ignores = propNode.SelectNodes("property")
								.OfType<XmlNode>()
								.SelectMany(n => n.InnerText.Split(splits, StringSplitOptions.RemoveEmptyEntries))
								.Distinct()
								.ToList()
					   };
			string filepath = Path.Combine(Path.Combine(workingPath, FilteredRepo), ".hgignore");
			using (StreamWriter sw = new StreamWriter(filepath))
			{
				sw.WriteLine("syntax: glob");
				foreach (var path in data.OrderBy(sp => sp.Path))
				{
					string shortPath = path.Path;
					if (shortPath.StartsWith(SVNUrl.Text))
						shortPath = shortPath.Substring(SVNUrl.Text.Length);
					if (shortPath.StartsWith("/"))
						shortPath = shortPath.Substring(1);
					if (shortPath.Length > 0)
						shortPath += "/";
					foreach (string ignore in path.Ignores)
						sw.WriteLine("{0}{1}", shortPath, ignore);
				}
			}

			DoCommand("hg", "add .hgignore", FilteredRepo);
			DoCommand("hg", "commit -m \"Committing .hgignore file generated from svn:ignore properties.\"", FilteredRepo);
		}

		private void LoadSvnIntoXml(object sender, EventArgs e)
		{
			svnDoc = new XmlDocument();
			svnDoc.LoadXml("<trunk />");
			
			string args = String.Format("ls {0} -R", SVNUrl.Text);
			CmdRunner cmd = new CmdRunner("svn", args, workingPath);
			List<string> lines = cmd.GetOutputLines();
			foreach (string line in lines)
			{
				if (String.IsNullOrEmpty(line))
					continue;

				XmlElement n = svnDoc.DocumentElement;
				var tn = SubrepoTree.Nodes;
				char[] splitChars = new char[] { '/' };
				string[] split = line.Split(splitChars);
				for(int i=0; i<split.Length; i++)
				{
					string s = split[i];
					if (String.IsNullOrEmpty(s))
						continue;

					XmlElement child = n.FindDirNode(s);
					var tChild = tn[s];
					if (child == null)
					{
						if (i + 1 < split.Length)
						{
							n.CreateChildDir(s);

							tChild = new TreeNode(s);
							tChild.Name = s;
							tn.Add(tChild);
						}
						else
							n.CreateChildFile(s);
					}
					n = child;
					if(tChild != null)
						tn = tChild.Nodes;
				}
			}
		}


		private void Done()
		{
			Log.Dispose();
			Verbose.Dispose();
			MessageBox.Show("Done");
		}

		private CmdRunner currentCmd = null;
		private void DoCommand(string command, string args, string relativeWorkingDir)
		{
			try
			{
				string wp = workingPath;
				if(relativeWorkingDir != null)
					wp = Path.Combine(wp, relativeWorkingDir);
				Directory.CreateDirectory(wp);
				CmdRunner cmd = new CmdRunner("hg", args, wp);
				cmd.Start();
				while (!cmd.Exited)
				{
					Thread.Sleep(100);
					string msg = cmd.LastMessage;
					if (!String.IsNullOrEmpty(msg))
						SetOutput(null, msg);
				}
			}
			finally
			{
				if (currentCmd != null)
				{
					currentCmd.Abort();
					currentCmd = null;
				}
			}
		}

		private void OnAbort(object sender, EventArgs e)
		{
			if (currentCmd != null)
			{
				currentCmd.Abort();
				currentCmd = null;
			}
			if(task != null)
				task.Cancel();
			Log.Dispose();
			Verbose.Dispose();
		}
	}
}
